export const ApplicationConstant = {
  HOME_PAGE_PATH: "/",
  LOGIN_URL_PATH: "/login",
  FORGOTPASSWORD_URL_PATH: "/forgotpassword",
  MYACCOUNT_URL: "/my-account",
  MYACCOUNT_PROFILE_URL: "profile",
  MYACCOUNT_MYINTERSHIPS_URL: "my-internships",
  MYACCOUNT_MYCERTIFICATES_URL: "my-certificates",
  MYACCOUNT_ADD_NEW_INTERNSHIP_URL: "add-new-internship",
  MYACCOUNT_EDIT_URL: "edit-profile",
};
