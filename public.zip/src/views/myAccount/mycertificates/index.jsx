const MyCertificates = () => {
    return ( 
        <div>
            MyCertificates
        </div>
     );
}
 
export default MyCertificates;