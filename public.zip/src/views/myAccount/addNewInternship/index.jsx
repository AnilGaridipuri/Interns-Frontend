const AddNewInternship = () => {
    return <div>AddNewInternship</div>;
}
 
export default AddNewInternship;