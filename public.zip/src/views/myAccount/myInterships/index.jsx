const MyInterships = () => {

  return (
    <div>
      My Inters
    </div>
  );
};

export default MyInterships;
