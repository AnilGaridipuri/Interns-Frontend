import SideBar from "../../../components/sideBar/sidebar";
import { Navigate, useParams } from "react-router-dom";
import '../myAccount.css'

const Profile = () => {
  return (
    <div className="profileBody">
      Profiledjfhkfbwekjfb
      dskjfchbwjsk,hckb
      wkjedwrweweqewwwwwwwwww
      wwwwwwwwwwweqweqeqeq
      erwrwerwerwewrwrrrrrrr
      rrrrrrrrrrrrrrrrrrrrrr
      rrrrrd,sbcjeksjdjvekdsj,
      vb ejdk njkdv,j nfjdk
      x,cn m jkchneuirheui
      rwriowm
      ho wriuhd wediuhaanil kumar garudipuri kdlhjncm
    </div>
  );
};

export default Profile;
